window.CHRVVIM_LEGAL = {
  "schema": "chrvvim-legal-library-v1",
  "status": "ready",
  "version": "1.0.0",
  "lastUpdated": "2025-10-15T00:00:00.000Z",
  "description": {
    "ar": "مكتبة قانونية - مستندات أصيلة مقدمة من المستخدم",
    "fr": "Bibliothèque juridique",
    "en": "Legal library"
  },
  "sources": [
    {
      "id": "chamber_reps",
      "name": {
        "ar": "مجلس النواب",
        "fr": "Chambre des représentants",
        "en": "Chamber of representatives"
      },
      "url": "https://chambredesrepresentants.ma",
      "verification": "verified"
    },
    {
      "id": "chamber_couns",
      "name": {
        "ar": "مجلس المستشارين",
        "fr": "Chambre des conseillers",
        "en": "Chamber of councillors"
      },
      "url": "https://chambredesconseillers.ma",
      "verification": "verified"
    },
    {
      "id": "ammc",
      "name": {
        "ar": "AMMC",
        "fr": "AMMC",
        "en": "AMMC"
      },
      "url": "https://ammc.ma",
      "verification": "verified"
    },
    {
      "id": "sgg_bo",
      "name": {
        "ar": "الجريدة الرسمية",
        "fr": "Bulletin Officiel",
        "en": "Official Gazette"
      },
      "url": "https://sgg.gov.ma",
      "verification": "unverified"
    },
    {
      "id": "justice",
      "name": {
        "ar": "وزارة العدل",
        "fr": "Ministère de la Justice",
        "en": "Ministry of Justice"
      },
      "url": "https://justice.gov.ma",
      "verification": "unverified"
    },
    {
      "id": "cassation",
      "name": {
        "ar": "محكمة النقض",
        "fr": "Cour de cassation",
        "en": "Court of Cassation"
      },
      "url": "https://courdecassation.ma",
      "verification": "unverified"
    },
    {
      "id": "user_docs",
      "name": {
        "ar": "مستندات المستخدم",
        "fr": "Documents utilisateur",
        "en": "User documents"
      },
      "url": null,
      "verification": "unverified"
    }
  ],
  "categories": [
    {
      "id": "judiciary",
      "name": {
        "ar": "التنظيم القضائي",
        "fr": "Organisation judiciaire",
        "en": "Judicial organization"
      }
    },
    {
      "id": "commercial",
      "name": {
        "ar": "القضاء التجاري",
        "fr": "Justice commerciale",
        "en": "Commercial justice"
      }
    },
    {
      "id": "civil_procedure",
      "name": {
        "ar": "المسطرة المدنية",
        "fr": "Procédure civile",
        "en": "Civil procedure"
      }
    },
    {
      "id": "criminal",
      "name": {
        "ar": "القانون الجنائي",
        "fr": "Droit pénal",
        "en": "Criminal law"
      }
    },
    {
      "id": "family",
      "name": {
        "ar": "قانون الأسرة",
        "fr": "Droit de la famille",
        "en": "Family law"
      }
    },
    {
      "id": "prosecution",
      "name": {
        "ar": "النيابة العامة",
        "fr": "Parquet",
        "en": "Public prosecution"
      }
    },
    {
      "id": "land",
      "name": {
        "ar": "التحفيظ العقاري",
        "fr": "Conservation foncière",
        "en": "Land registration"
      }
    },
    {
      "id": "constitution",
      "name": {
        "ar": "الدستور",
        "fr": "Constitution",
        "en": "Constitution"
      }
    },
    {
      "id": "labor",
      "name": {
        "ar": "قانون الشغل",
        "fr": "Droit du travail",
        "en": "Labor law"
      }
    },
    {
      "id": "administrative",
      "name": {
        "ar": "القانون الإداري",
        "fr": "Droit administratif",
        "en": "Administrative law"
      }
    },
    {
      "id": "real_estate",
      "name": {
        "ar": "العقارات",
        "fr": "Immobilier",
        "en": "Real estate"
      }
    },
    {
      "id": "taxonomy",
      "name": {
        "ar": "متنوع",
        "fr": "Divers",
        "en": "Misc."
      }
    }
  ],
  "documents": [
    {
      "id": "doc_001",
      "type": "report",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تقرير تركيبي حول التنظيم القضائي",
        "fr": "تقرير تركيبي حول التنظيم القضائي",
        "en": "تقرير تركيبي حول التنظيم القضائي"
      },
      "author": "عبد المجيد غميجة",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تقرير تركيبي حول التنظيم القضائي، صادر عن وزارة العدل والحريات في سياق الحوار الوطني حول إصلاح منظومة العدالة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_002",
      "type": "study",
      "category": "commercial",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "قانون معالجة صعوبات المقاولة وسيلة للمعالجة القانونية للصعوبات المالية للمقاولة",
        "fr": "قانون معالجة صعوبات المقاولة وسيلة للمعالجة القانونية للصعوبات المالية للمقاولة",
        "en": "قانون معالجة صعوبات المقاولة وسيلة للمعالجة القانونية للصعوبات المالية للمقاولة"
      },
      "author": "د. محمد أبو الحسن",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول قانون معالجة صعوبات المقاولة كآلية قانونية لمعالجة الصعوبات المالية للمقاولة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "commercial",
        "authentic"
      ]
    },
    {
      "id": "doc_003",
      "type": "report",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تقرير تركيبي حول الخبرة القضائية",
        "fr": "تقرير تركيبي حول الخبرة القضائية",
        "en": "تقرير تركيبي حول الخبرة القضائية"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تقرير تركيبي يتناول الخبرة القضائية، يشير إلى القانون رقم 44.00."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_004",
      "type": "study",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "صلاحيات المجلس الأعلى للسلطة القضائية في ضوء التجارب المقارنة",
        "fr": "صلاحيات المجلس الأعلى للسلطة القضائية في ضوء التجارب المقارنة",
        "en": "صلاحيات المجلس الأعلى للسلطة القضائية في ضوء التجارب المقارنة"
      },
      "author": "مصطفى التراب، الرئيس الأول لمحكمة الاستئناف بالدار البيضاء",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة مقارنة حول صلاحيات المجلس الأعلى للسلطة القضائية في ضوء التجارب المقارنة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_005",
      "type": "report",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تقرير تركيبي حول مهنة النساخة",
        "fr": "تقرير تركيبي حول مهنة النساخة",
        "en": "تقرير تركيبي حول مهنة النساخة"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تقرير صادر عن وزارة العدل والحريات - مديرية الشؤون المدنية، يتناول مهنة النساخة، ويشير إلى القانون رقم 49.00."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_006",
      "type": "study",
      "category": "criminal",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "سياسة التجريم الواقع والآفاق",
        "fr": "سياسة التجريم الواقع والآفاق",
        "en": "سياسة التجريم الواقع والآفاق"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "ورقة بحثية حول سياسة التجريم، الواقع والآفاق، قدمت ضمن فعاليات الحوار الوطني حول إصلاح منظومة العدالة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "criminal",
        "authentic"
      ]
    },
    {
      "id": "doc_007",
      "type": "study",
      "category": "commercial",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تصورات لتأهيل القضاء التجاري",
        "fr": "تصورات لتأهيل القضاء التجاري",
        "en": "تصورات لتأهيل القضاء التجاري"
      },
      "author": "الأستاذ محمد هيبة، رئيس القسم التجاري بالمحكمة الابتدائية بالدار البيضاء",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تصورات لتأهيل القضاء التجاري ضمن العروض المقدمة أمام اللجنة العليا للحوار الوطني سنة 2012."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "commercial",
        "authentic"
      ]
    },
    {
      "id": "doc_008",
      "type": "report",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تقرير تركيبي حول تكوين الموظفين والأعوان المكلفين بمهام الشرطة القضائية",
        "fr": "تقرير تركيبي حول تكوين الموظفين والأعوان المكلفين بمهام الشرطة القضائية",
        "en": "تقرير تركيبي حول تكوين الموظفين والأعوان المكلفين بمهام الشرطة القضائية"
      },
      "author": "الأستاذة ليلى المريني",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تقرير تركيبي حول تكوين الموظفين والأعوان المكلفين بمهام الشرطة القضائية وموظفي المندوبية العامة لإدارة السجون وإعادة الإدماج، ضمن عروض الحوار الوطني سنة 2012."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_009",
      "type": "report",
      "category": "commercial",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "تشخيص واقع القضاء التجاري",
        "fr": "تشخيص واقع القضاء التجاري",
        "en": "تشخيص واقع القضاء التجاري"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "تشخيص واقع القضاء التجاري بالمغرب، أعده مدير الشؤون المدنية بوزارة العدل والحريات."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "commercial",
        "authentic"
      ]
    },
    {
      "id": "doc_011",
      "type": "study",
      "category": "family",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "النيابة العامة والصلح الأسري على ضوء مدونة الأسرة",
        "fr": "النيابة العامة والصلح الأسري على ضوء مدونة الأسرة",
        "en": "النيابة العامة والصلح الأسري على ضوء مدونة الأسرة"
      },
      "author": "د. محسن البقالي الحسني، وكيل الملك لدى المحكمة الابتدائية بالعرائش",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول دور النيابة العامة والصلح الأسري على ضوء مدونة الأسرة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "family",
        "authentic"
      ]
    },
    {
      "id": "doc_012",
      "type": "lecture",
      "category": "criminal",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "محاضرات في القانون الجنائي الخاص",
        "fr": "محاضرات في القانون الجنائي الخاص",
        "en": "محاضرات في القانون الجنائي الخاص"
      },
      "author": "عبد الرحمان الباقوري",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "محاضرات في القانون الجنائي الخاص للأستاذ عبد الرحمان الباقوري."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "criminal",
        "authentic"
      ]
    },
    {
      "id": "doc_013",
      "type": "draft",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "الصيغة الأخيرة والنهائية لمشروع التنظيم القضائي",
        "fr": "الصيغة الأخيرة والنهائية لمشروع التنظيم القضائي",
        "en": "الصيغة الأخيرة والنهائية لمشروع التنظيم القضائي"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "الصيغة الأخيرة والنهائية لمشروع قانون يتعلق بالتنظيم القضائي كما وافقت عليه لجنة العدل والتشريع وحقوق الإنسان بمجلس المستشارين."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_014",
      "type": "guide",
      "category": "prosecution",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "مهام النيابة العامة",
        "fr": "مهام النيابة العامة",
        "en": "مهام النيابة العامة"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "مرجع يوضح مهام النيابة العامة لدى المحاكم الابتدائية ودورها في الدعوى العمومية والمدنية والقوانين الخاصة."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "prosecution",
        "authentic"
      ]
    },
    {
      "id": "doc_015",
      "type": "guide",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "نوازل وحلول في المسطرة المدنية",
        "fr": "نوازل وحلول في المسطرة المدنية",
        "en": "نوازل وحلول في المسطرة المدنية"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دليل عملي يتناول نوازل وحلول في المسطرة المدنية."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_016",
      "type": "study",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "الدفع بخرق الفصل التاسع من قانون المسطرة المدنية على ضوء الاجتهاد",
        "fr": "الدفع بخرق الفصل التاسع من قانون المسطرة المدنية على ضوء الاجتهاد",
        "en": "الدفع بخرق الفصل التاسع من قانون المسطرة المدنية على ضوء الاجتهاد"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول الدفع بخرق الفصل التاسع من قانون المسطرة المدنية على ضوء الاجتهاد القضائي (مستند أساسا مصور - لا يحتوي على طبقة نص)."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_017",
      "type": "guide",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "إجراءات تحقيق الدعوى",
        "fr": "إجراءات تحقيق الدعوى",
        "en": "إجراءات تحقيق الدعوى"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "مرجع حول إجراءات تحقيق الدعوى في المسطرة المدنية."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_018",
      "type": "guide",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "الموجز في المسطرة المدنية",
        "fr": "الموجز في المسطرة المدنية",
        "en": "الموجز في المسطرة المدنية"
      },
      "author": "د. الناصري",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "الموجز في المسطرة المدنية للدكتور الناصري."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_019",
      "type": "study",
      "category": "land",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "خصوصيات الإجراءات في مسطرة التحفيظ العقاري",
        "fr": "خصوصيات الإجراءات في مسطرة التحفيظ العقاري",
        "en": "خصوصيات الإجراءات في مسطرة التحفيظ العقاري"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول خصوصيات الإجراءات في مسطرة التحفيظ العقاري."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "land",
        "authentic"
      ]
    },
    {
      "id": "doc_020",
      "type": "study",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "الطلبات العارضة في قانون المسطرة المدنية المغربي والقانون المقارن",
        "fr": "الطلبات العارضة في قانون المسطرة المدنية المغربي والقانون المقارن",
        "en": "الطلبات العارضة في قانون المسطرة المدنية المغربي والقانون المقارن"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة مقارنة حول الطلبات العارضة في قانون المسطرة المدنية المغربي والقانون المقارن (مستند أساسا مصور - لا يحتوي على طبقة نص)."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    },
    {
      "id": "doc_021",
      "type": "study",
      "category": "family",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "خصوصيات المسطرة في القضايا الأسرية",
        "fr": "خصوصيات المسطرة في القضايا الأسرية",
        "en": "خصوصيات المسطرة في القضايا الأسرية"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول خصوصيات المسطرة في القضايا الأسرية."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "family",
        "authentic"
      ]
    },
    {
      "id": "doc_022",
      "type": "study",
      "category": "judiciary",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "حقوق المتقاضين وقواعد سير العدالة في علاقتها بالحكامة القضائية",
        "fr": "حقوق المتقاضين وقواعد سير العدالة في علاقتها بالحكامة القضائية",
        "en": "حقوق المتقاضين وقواعد سير العدالة في علاقتها بالحكامة القضائية"
      },
      "author": "عبد الرحمان الباقوري",
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول حقوق المتقاضين وقواعد سير العدالة في علاقتها بالحكامة القضائية، للأستاذ عبد الرحمان الباقوري."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "judiciary",
        "authentic"
      ]
    },
    {
      "id": "doc_023",
      "type": "study",
      "category": "civil_procedure",
      "jurisdiction": "MA",
      "language": "ar",
      "title": {
        "ar": "سلامة الإجراءات المسطرية من خلال التبليغ القضائي",
        "fr": "سلامة الإجراءات المسطرية من خلال التبليغ القضائي",
        "en": "سلامة الإجراءات المسطرية من خلال التبليغ القضائي"
      },
      "author": null,
      "reference": null,
      "date": null,
      "summary": {
        "ar": "دراسة حول سلامة الإجراءات المسطرية من خلال التبليغ القضائي (مستند أساسا مصور - لا يحتوي على طبقة نص)."
      },
      "sourceId": "user_docs",
      "sourceUrl": null,
      "pdfUrl": null,
      "verification": {
        "status": "unverified",
        "reason": "metadata inferred from filename/authentic document; numeric dates may be affected by RTL extraction encoding"
      },
      "tags": [
        "civil_procedure",
        "authentic"
      ]
    }
  ],
  "documentTypes": [
    {
      "id": "report",
      "name": {
        "ar": "تقرير",
        "fr": "Rapport",
        "en": "Report"
      }
    },
    {
      "id": "study",
      "name": {
        "ar": "دراسة",
        "fr": "Étude",
        "en": "Study"
      }
    },
    {
      "id": "lecture",
      "name": {
        "ar": "محاضرات",
        "fr": "Cours",
        "en": "Lectures"
      }
    },
    {
      "id": "draft",
      "name": {
        "ar": "مشروع قانون",
        "fr": "Projet de loi",
        "en": "Draft law"
      }
    },
    {
      "id": "guide",
      "name": {
        "ar": "دليل",
        "fr": "Guide",
        "en": "Guide"
      }
    },
    {
      "id": "law",
      "name": {
        "ar": "قانون",
        "fr": "Loi",
        "en": "Law"
      }
    },
    {
      "id": "decree",
      "name": {
        "ar": "ظهير/مرسوم",
        "fr": "Décret",
        "en": "Decree"
      }
    },
    {
      "id": "decision",
      "name": {
        "ar": "قرار",
        "fr": "Décision",
        "en": "Decision"
      }
    },
    {
      "id": "convention",
      "name": {
        "ar": "اتفاقية",
        "fr": "Convention",
        "en": "Convention"
      }
    },
    {
      "id": "article",
      "name": {
        "ar": "مقال/نص",
        "fr": "Article",
        "en": "Article"
      }
    },
    {
      "id": "jurisprudence",
      "name": {
        "ar": "اجتهاد قضائي",
        "fr": "Jurisprudence",
        "en": "Jurisprudence"
      }
    },
    {
      "id": "thesis",
      "name": {
        "ar": "أطروحة",
        "fr": "Thèse",
        "en": "Thesis"
      }
    }
  ],
  "jurisdictions": [
    {
      "id": "ma",
      "name": {
        "ar": "المغرب",
        "fr": "Maroc",
        "en": "Morocco"
      }
    },
    {
      "id": "other",
      "name": {
        "ar": "أجنبي/مقارن",
        "fr": "étranger/comparé",
        "en": "foreign/comparative"
      }
    }
  ]
};
